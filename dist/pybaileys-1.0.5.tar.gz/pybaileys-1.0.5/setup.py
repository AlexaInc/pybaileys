from setuptools import setup

# This setup() call triggers the reading of pyproject.toml
setup()